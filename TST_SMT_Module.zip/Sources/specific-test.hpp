// Variable content file
// !!!! Generated file, do not edit

#include "tst_str.hpp"

// End of generated variable content file
