// Starting value for the specific-test.hpp file
// !!!! Generated file, do not edit
// End of generated variable content file
